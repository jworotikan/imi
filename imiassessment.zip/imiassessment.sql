-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.1.32-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win32
-- HeidiSQL Version:             9.5.0.5196
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for imiass
DROP DATABASE IF EXISTS `imiass`;
CREATE DATABASE IF NOT EXISTS `imiass` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `imiass`;

-- Dumping structure for table imiass.dbass
DROP TABLE IF EXISTS `dbass`;
CREATE TABLE IF NOT EXISTS `dbass` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ass_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table imiass.dbass: ~0 rows (approximately)
DELETE FROM `dbass`;
/*!40000 ALTER TABLE `dbass` DISABLE KEYS */;
INSERT INTO `dbass` (`id`, `ass_name`) VALUES
	(1, 'Test Pendelegasian');
/*!40000 ALTER TABLE `dbass` ENABLE KEYS */;

-- Dumping structure for table imiass.dbqst
DROP TABLE IF EXISTS `dbqst`;
CREATE TABLE IF NOT EXISTS `dbqst` (
  `id` int(11) DEFAULT NULL,
  `ass_id` int(11) DEFAULT NULL,
  `q_txt` varchar(50) DEFAULT NULL,
  `ans_type` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table imiass.dbqst: ~0 rows (approximately)
DELETE FROM `dbqst`;
/*!40000 ALTER TABLE `dbqst` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbqst` ENABLE KEYS */;

-- Dumping structure for table imiass.db_answ
DROP TABLE IF EXISTS `db_answ`;
CREATE TABLE IF NOT EXISTS `db_answ` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) DEFAULT NULL,
  `answer` varchar(50) DEFAULT NULL,
  `ans_pos` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- Dumping data for table imiass.db_answ: ~8 rows (approximately)
DELETE FROM `db_answ`;
/*!40000 ALTER TABLE `db_answ` DISABLE KEYS */;
INSERT INTO `db_answ` (`id`, `type`, `answer`, `ans_pos`) VALUES
	(1, 1, 'Selalu', 1),
	(2, 1, 'Kadang-Kadang', 2),
	(3, 1, 'Jarang', 3),
	(4, 2, 'Tidak Pernah', 1),
	(5, 2, 'Hampir Tidak Pernah', 2),
	(6, 2, 'Kadang-Kadang', 3),
	(7, 2, 'Sering', 4),
	(8, 2, 'Sangat Sering', 5);
/*!40000 ALTER TABLE `db_answ` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
